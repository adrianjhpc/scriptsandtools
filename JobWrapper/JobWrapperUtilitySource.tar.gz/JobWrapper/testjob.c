#include<stdio.h>
#include<stdlib.h>


int main(int argc, char **argv){

  int sleeparg;

  if(argc != 2){
     printf("Wrong number of arguments, expecting one argument specifying time to run program for\n");
     return 1;
  }else{
    sleeparg = atoi(argv[1]);
    printf("Doing %d\n",sleeparg);
  }

  sleep(sleeparg);

  printf("Done %d\n",sleeparg);

  exit;

}
