1. Edit the jobscript.sh batch job file script appropriately
   Specifically add the correct executable names and locations to the EXE1 and EXE2 variable
   This tool is only setup to run 2 programs on a node at the moment, but you can change the 
   NTHREADS_1 and NTHREADS_2 variable to less than 12 if required (they cannot be more than 12).
   You can also add arguments to be passed to each executable and change where they write output 
   text and error text.
   It is likely you will also have to alter the PBS budget and walltime settings.

2. Submit the job. Type:
   qsub jobscript.sh

